# ⚡ HOCRAL HUB EXECUTOR (Pure Native C# WPF x64)

Премиальный, высокопроизводительный Lua/Luau экзекутор и скрипт-хаб для Roblox с интерфейсом в стиле **[hocral.ru](https://www.hocral.ru)**.

Приложение **на 100% написано на чистом C# (.NET Framework 4.8 / WPF)** с современным интерфейсом и редактором Monaco. Движок `HocralAPI.dll` загружается напрямую внутри одного процесса.

---

## 🌟 Возможности

1. **🔥 Нативный редактор кода Luau**:
   - Быстрый многовкладочный редактор (Tabs) с поддержкой добавления, переключения и закрытия вкладок
   - Нумерация строк и плавная синхронная прокрутка
   - Моноширинный шрифт (`Consolas`, `JetBrains Mono`)
   - Поддержка отступов и горячих клавиш

2. **⚡ Мгновенный внутрипроцессный Execute**:
   - Выполнение скриптов напрямую через `HocralAPI.dll`
   - Мульти-клиентное исполнение (скрипт выполняется во всех открытых клиентах Roblox)
   - Нулевая задержка, отсутствие промежуточных процессов или пайпов

3. **💉 Инжектор & Авто-мониторинг**:
   - Быстрое подключение к процессу `RobloxPlayerBeta.exe`
   - Фоновый трекер статуса Roblox в реальном времени с индикатором готовности
   - Опция автоматического подключения (Auto-Attach)

4. **📦 Встроенный HOCRAL Script Hub (16 скриптов)**:
   - **Infinite Yield FE** (Универсальный админ с 300+ командами)
   - **Dark Dex V3 Explorer** (Инспектор Workspace и объектов)
   - **SimpleSpy V2** (Логгер RemoteEvent & RemoteFunction)
   - **Hydroxide Luau Debugger**
   - **Blox Fruits** (Redz Hub, Hoho Hub Auto Farm)
   - **Arsenal** (Thunder Hub)
   - **Blade Ball** (Auto Parry God)
   - **Pet Simulator 99**, **Doors**, **Fly & Noclip**, **Touch Fling**, **Anti-AFK**
   - Поиск в реальном времени и фильтрация по категориям

5. **📁 Управление локальными скриптами**:
   - Локальная папка `scripts/` для ваших `.lua` файлов
   - Быстрый запуск в 1 клик, загрузка в редактор и удаление

6. **💻 Live Console & Debugger**:
   - Встроенный терминал вывода логов ядра и Roblox с временными метками
   - Цветовая индикация тегов: `[INFO]`, `[SUCCESS]`, `[EXEC]`, `[ERROR]`
   - Очистка и копирование логов в буфер обмена

7. **🎨 Фирменный дизайн сайта hocral.ru**:
   - Глубокая полночная палитра Midnight Obsidian (`#0c0a14`, `#141026`) с неоновым акцентом Indigo Blurple (`#6366f1`, `#818cf8`)
   - Фирменный логотип-аватар `icon.png`, бейдж `HUB`, динамический статус-пил
   - Быстрые индикаторы: 144 FPS, UNC 100% Level 8, Roblox Watchdog
   - Безрамочное окно с плавным перетаскиванием и кнопкой закрепления поверх окон (Pin / Always on top)

---

## 🚀 Запуск приложения

- **Вариант 1 (Ярлык):** Откройте `HOCRAL EXECUTOR.lnk` в корневой папке
- **Вариант 2 (Исполняемый файл):** Откройте папку `HocralHub/` и запустите `HocralHub.exe`

---

## 🔨 Сборка из исходников

Для сборки проекта из исходного кода в папке `Source/`:
```bash
dotnet build Source\HocralApp.csproj -c Release -r win-x64
```
Сборка происходит за ~1 секунду напрямую в папку `HocralHub/`.

---

## 📂 Структура каталога

```
HOCRAL HUB EXECUTOR/
│
├── HOCRAL EXECUTOR.lnk        # 🚀 Ярлык быстрого запуска
│
├── HocralHub/                 # 📦 Автономная папка готового приложения
│   ├── HocralHub.exe          # Нативный исполняемый файл C# (WPF x64)
│   ├── HocralHub.exe.config   # Конфигурация .NET рантайма
│   ├── HocralAPI.dll          # Фирменное ядро HocralHub инжектора и выполнения Luau
│   ├── WebView2Loader.dll     # Загрузчик движка Monaco Editor
│   ├── Microsoft.Web.WebView2.*.dll # Библиотеки Monaco WebView2
│   ├── monaco/                # Локальные ассеты Microsoft Monaco Editor
│   ├── Bin/                   # Системные бинарные модули движка (Overlay, Decompiler)
│   ├── favicon.ico / icon.png # Графика и иконки приложения
│   ├── scripts/               # Папка для пользовательских скриптов
│   ├── AutoExec/              # Папка для автозапуска скриптов
│   └── Workspace/             # Рабочая папка скриптов
│
├── Source/                    # 💻 Чистый исходный код C# (WPF)
│   ├── HocralApp.csproj
│   ├── App.xaml / App.xaml.cs
│   ├── MainWindow.xaml / MainWindow.xaml.cs
│   ├── ScriptDatabase.cs
│   └── app.manifest
│
├── monaco/                    # Исходные файлы редактора Monaco
└── README.md                  # Документация проекта
```
