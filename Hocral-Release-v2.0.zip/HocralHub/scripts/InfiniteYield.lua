-- [HOCRAL HUB] Infinite Yield FE Universal Admin
-- Loads the official Infinite Yield script suite
loadstring(game:HttpGet('https://raw.githubusercontent.com/EdgeIY/infiniteyield/master/source'))()
print("[HOCRAL EXECUTOR] Infinite Yield Loaded successfully!")
