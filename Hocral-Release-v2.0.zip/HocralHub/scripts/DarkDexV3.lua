-- [HOCRAL HUB] Dark Dex V3 Workspace Explorer
loadstring(game:HttpGet("https://raw.githubusercontent.com/infyiff/backup/main/dex.lua"))()
print("[HOCRAL EXECUTOR] Dark Dex V3 Loaded!")
