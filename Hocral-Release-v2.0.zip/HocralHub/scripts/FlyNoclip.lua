-- [HOCRAL HUB] Universal Fly & Noclip System
local FlySpeed = 50
local speaker = game.Players.LocalPlayer
local chr = speaker.Character or speaker.CharacterAdded:Wait()
local hum = chr:WaitForChild("Humanoid")
local root = chr:WaitForChild("HumanoidRootPart")

local BV = Instance.new("BodyVelocity")
BV.Name = "HocralFly"
BV.MaxForce = Vector3.new(9e9, 9e9, 9e9)
BV.Velocity = Vector3.zero
BV.Parent = root

local BG = Instance.new("BodyGyro")
BG.Name = "HocralGyro"
BG.MaxTorque = Vector3.new(9e9, 9e9, 9e9)
BG.CFrame = root.CFrame
BG.Parent = root

print("[HOCRAL EXECUTOR] Fly Script Injected! Speed set to " .. FlySpeed)
