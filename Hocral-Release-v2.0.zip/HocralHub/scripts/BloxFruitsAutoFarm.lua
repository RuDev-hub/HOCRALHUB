-- [HOCRAL HUB] Blox Fruits Redz Hub Loader
loadstring(game:HttpGet("https://raw.githubusercontent.com/REDzHUB/BloxFruits/main/redz9999"))()
print("[HOCRAL EXECUTOR] Blox Fruits Auto Farm Initialized!")
