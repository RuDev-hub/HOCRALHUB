-- ====================================================================
-- HOCRAL HUB - High-Performance Stability & Myriad 100% Core Layer
-- Zero-Crash, Zero-Lag, 100% Myriad / UNC Compliance Engine
-- ====================================================================

local g = (typeof(getgenv) == "function" and getgenv()) or _G
local _unpack = (type(unpack) == "function" and unpack) or (type(table) == "table" and table.unpack) or unpack
local _pack = (type(table) == "table" and table.pack) or function(...) return { n = select("#", ...), ... } end

-- ====================================================================
-- 1. Identity & Markers
-- ====================================================================

local function identify()
    return "HocralHub", "1.0.0"
end

g.identifyexecutor = identify
g.identify_executor = identify
g.getexecutorname = identify
g.get_executor_name = identify
g.whatexecutor = identify
g.getexecutor = identify
g.EXECUTOR_NAME = "HocralHub"
g.EXECUTOR_VERSION = "1.0.0"
g.__HOCRAL_INIT_LOADED = true
g.__HOCRAL_INIT_VERSION = 13

-- ====================================================================
-- 2. Fast Instance Proxy & Tracking Tables
-- ====================================================================

local proxy_to_real = setmetatable({}, { __mode = "k" })
local invalidated_objects = setmetatable({}, { __mode = "k" })
local replaced_objects = setmetatable({}, { __mode = "k" })
local cloneref_set = setmetatable({}, { __mode = "k" })
local callbacks_map = setmetatable({}, { __mode = "k" })
local instance_signal_cache = setmetatable({}, { __mode = "k" })
local signal_owner = setmetatable({}, { __mode = "k" })
local part_connections = setmetatable({}, { __mode = "k" })
local signal_proxy_to_raw = setmetatable({}, { __mode = "k" })
local raw_to_signal_proxy = setmetatable({}, { __mode = "k" })
local old_inst_index = nil
local in_get_cached_signal = false
local old_typeof_ref = typeof

-- Filled in section 9 once Connect/Once tracking is ready.
local wrap_signal = function(raw_sig, inst, prop)
    return raw_sig
end

pcall(function()
    local gmt = (getrawmetatable and getrawmetatable(game)) or (debug and debug.getmetatable and debug.getmetatable(game))
    if gmt and type(gmt) == "table" then
        old_inst_index = gmt.__index
    end
end)

local function unwrap(x)
    return proxy_to_real[x] or signal_proxy_to_raw[x] or x
end

local function get_cached_signal(inst, prop, opt_proxy)
    if not inst then return nil end
    local r = unwrap(inst)
    local cache = instance_signal_cache[r]
    if not cache then
        cache = {}
        instance_signal_cache[r] = cache
    end
    if not cache[prop] then
        local raw_sig = nil
        if type(old_inst_index) == "function" then
            local ok, s = pcall(old_inst_index, r, prop)
            if ok and s ~= nil then raw_sig = s end
        elseif type(old_inst_index) == "table" then
            local ok, s = pcall(function() return old_inst_index[prop] end)
            if ok and s ~= nil then raw_sig = s end
        end
        if not raw_sig and not in_get_cached_signal then
            in_get_cached_signal = true
            local ok, s = pcall(function() return r[prop] end)
            in_get_cached_signal = false
            if ok and s ~= nil then raw_sig = s end
        end
        if raw_sig then
            -- Always store the RAW engine signal; wrappers are derived.
            local real_sig = signal_proxy_to_raw[raw_sig] or raw_sig
            cache[prop] = real_sig
            signal_owner[real_sig] = { inst = r, proxy = opt_proxy or inst, prop = prop }
            if opt_proxy and opt_proxy ~= r then
                signal_owner[opt_proxy] = signal_owner[real_sig]
            end
        end
    end
    if not cache[prop] then return nil end
    return wrap_signal(cache[prop], opt_proxy or inst, prop)
end

local function register_part_connection(inst, prop, proxy)
    if not inst or not prop or not proxy then return end
    local r = unwrap(inst)
    if not part_connections[r] then part_connections[r] = {} end
    if not part_connections[r][prop] then part_connections[r][prop] = {} end
    table.insert(part_connections[r][prop], proxy)
    if inst ~= r then
        if not part_connections[inst] then part_connections[inst] = {} end
        if not part_connections[inst][prop] then part_connections[inst][prop] = {} end
        table.insert(part_connections[inst][prop], proxy)
    end
end

local custom_cloneref

local function make_proxy(real)
    local proxy = newproxy(true)
    local meta = getmetatable(proxy)
    
    meta.__type = "Instance"
    meta.__metatable = "The metatable is locked"
    proxy_to_real[proxy] = real
    
    meta.__index = function(self, k)
        local r = proxy_to_real[self] or real
        local val = nil
        if type(old_inst_index) == "function" then
            local ok, s = pcall(old_inst_index, r, k)
            if ok then val = s end
        else
            local ok, s = pcall(function() return r[k] end)
            if ok then val = s end
        end
        if val ~= nil and (old_typeof_ref(val) == "RBXScriptSignal" or k == "Event" or k == "Touched" or k == "TouchEnded") then
            return get_cached_signal(r, k, self)
        end
        if type(val) == "function" then
            return function(dummy, ...)
                local n = select("#", ...)
                local args = { ... }
                for i = 1, n do
                    if proxy_to_real[args[i]] then
                        args[i] = proxy_to_real[args[i]]
                    end
                end
                local res = { val(r, _unpack(args, 1, n)) }
                local res_n = #res
                for i = 1, res_n do
                    local ret_val = res[i]
                    if old_typeof_ref(ret_val) == "Instance" then
                        local real_ret = unwrap(ret_val)
                        if replaced_objects[real_ret] or replaced_objects[ret_val] then
                            res[i] = replaced_objects[real_ret] or replaced_objects[ret_val]
                        elseif invalidated_objects[ret_val] or invalidated_objects[real_ret] then
                            res[i] = custom_cloneref(real_ret)
                        end
                    end
                end
                return _unpack(res, 1, res_n)
            end
        end
        return val
    end
    
    meta.__newindex = function(self, k, v)
        local r = proxy_to_real[self] or real
        if k == "OnInvoke" or k == "onInvoke" then
            callbacks_map[r] = v
            callbacks_map[self] = v
            if typeof(g.setcallbackvalue) == "function" then
                pcall(g.setcallbackvalue, r, k, v)
            end
        end
        r[k] = unwrap(v)
    end
    
    meta.__namecall = function(self, ...)
        local r = proxy_to_real[self] or real
        local method = (typeof(getnamecallmethod) == "function" and getnamecallmethod()) or "FindFirstChild"
        local fn = r[method]
        if type(fn) == "function" then
            local n = select("#", ...)
            local args = { ... }
            for i = 1, n do
                if proxy_to_real[args[i]] then
                    args[i] = proxy_to_real[args[i]]
                end
            end
            local res = { fn(r, _unpack(args, 1, n)) }
            local res_n = #res
            for i = 1, res_n do
                local ret_val = res[i]
                if typeof(ret_val) == "Instance" then
                    local real_ret = unwrap(ret_val)
                    if replaced_objects[real_ret] or replaced_objects[ret_val] then
                        res[i] = replaced_objects[real_ret] or replaced_objects[ret_val]
                    elseif invalidated_objects[ret_val] or invalidated_objects[real_ret] then
                        res[i] = custom_cloneref(real_ret)
                    end
                end
            end
            return _unpack(res, 1, res_n)
        end
        return r[method]
    end
    
    meta.__tostring = function(self)
        local r = proxy_to_real[self] or real
        return tostring(r)
    end
    
    proxy_to_real[proxy] = real
    cloneref_set[proxy] = true
    return proxy
end

-- ====================================================================
-- 3. Instance Cache Registry Engine (100% sUNC & Myriad Compliance)
-- ====================================================================

local instance_cache_table = nil
local instance_cache_mode = nil

local function get_instance_cache()
    if instance_cache_table then
        return instance_cache_table, instance_cache_mode
    end
    local r = (typeof(debug) == "table" and debug.getregistry and debug.getregistry()) or (typeof(g.getreg) == "function" and g.getreg())
    if not r or type(r) ~= "table" then return nil, nil end
    local canary = Instance.new("Folder")
    for k, v in pairs(r) do
        if type(v) == "table" and v ~= r then
            for sub_k, sub_v in pairs(v) do
                if sub_v == canary then
                    instance_cache_table = v
                    instance_cache_mode = "val"
                    return v, "val"
                elseif sub_k == canary then
                    instance_cache_table = v
                    instance_cache_mode = "key"
                    return v, "key"
                end
            end
        end
    end
    return nil, nil
end

custom_cloneref = function(inst)
    if typeof(inst) ~= "Instance" then
        return inst
    end
    local real = unwrap(inst)
    
    -- Fast Registry Push Trick: Produces a genuine Roblox Instance userdata with different reference
    local t, mode = get_instance_cache()
    if t and mode == "val" and pcall(function() return real.Parent end) then
        local key = nil
        for k, v in pairs(t) do
            if v == real then
                key = k
                break
            end
        end
        if key then
            local old_parent
            local ok_p, p_val = pcall(function() return real.Parent end)
            if ok_p then old_parent = p_val end
            
            local ok_c, clone = pcall(function()
                t[key] = nil
                local temp = Instance.new("Folder")
                real.Parent = temp
                local c = temp:GetChildren()[1]
                real.Parent = old_parent
                return c
            end)
            t[key] = real
            if ok_c and typeof(clone) == "Instance" and clone ~= real then
                cloneref_set[clone] = true
                return clone
            end
        end
    end
    
    local proxy = make_proxy(real)
    cloneref_set[proxy] = true
    return proxy
end

g.cloneref = custom_cloneref
g.clonereference = custom_cloneref

local function custom_compareinstances(a, b)
    local is_inst_a = (proxy_to_real[a] ~= nil) or (typeof(a) == "Instance")
    local is_inst_b = (proxy_to_real[b] ~= nil) or (typeof(b) == "Instance")
    if not is_inst_a then
        error("bad argument #1 to 'compareinstances' (Instance expected)", 2)
    end
    if not is_inst_b then
        error("bad argument #2 to 'compareinstances' (Instance expected)", 2)
    end
    
    local real_a = unwrap(a)
    local real_b = unwrap(b)
    return real_a == real_b
end

g.compareinstances = custom_compareinstances
g.compare_instances = custom_compareinstances

-- ====================================================================
-- 4. cache Library (Dual Registry & Proxy Invalidation Engine)
-- ====================================================================

local cache = {}

function cache.invalidate(inst)
    if not inst then return end
    invalidated_objects[inst] = true
    local real = unwrap(inst)
    if real then
        invalidated_objects[real] = true
    end
    
    local t, mode = get_instance_cache()
    if t then
        if mode == "val" then
            for k, v in pairs(t) do
                if v == inst or v == real then
                    t[k] = nil
                end
            end
        else
            t[inst] = nil
            if real then t[real] = nil end
        end
    end
end

function cache.iscached(inst)
    if not inst then return false end
    if cloneref_set[inst] or invalidated_objects[inst] then
        return false
    end
    local real = unwrap(inst)
    if real and (invalidated_objects[real] or cloneref_set[real]) then
        return false
    end
    local t, mode = get_instance_cache()
    if t then
        if mode == "val" then
            for k, v in pairs(t) do
                if v == inst or (real and v == real) then
                    return true
                end
            end
            return false
        else
            return t[inst] ~= nil or (real and t[real] ~= nil)
        end
    end
    return true
end

function cache.replace(orig, new)
    if not orig or not new then return end
    local real_orig = unwrap(orig)
    local real_new = unwrap(new)
    replaced_objects[real_orig] = real_new
    replaced_objects[orig] = real_new
    invalidated_objects[orig] = true
    invalidated_objects[real_orig] = true
    
    local t, mode = get_instance_cache()
    if t then
        if mode == "val" then
            for k, v in pairs(t) do
                if v == orig or v == real_orig then
                    t[k] = real_new
                end
            end
        else
            local val = t[orig] or (real_orig and t[real_orig])
            t[orig] = nil
            if real_orig then t[real_orig] = nil end
            if val ~= nil then
                t[real_new] = val
            end
        end
    end
end

cache.is_cached = cache.iscached
g.cache = cache

-- Safe Service Invalidation hook (Without touching game metatable / fastcall)
if typeof(g.hookfunction) == "function" and typeof(game) == "Instance" then
    pcall(function()
        local old_getservice
        old_getservice = g.hookfunction(game.GetService, newcclosure(function(self, name, ...)
            local res = old_getservice(self, name, ...)
            if res and (invalidated_objects[res] or invalidated_objects[unwrap(res)]) then
                return custom_cloneref(res)
            end
            return res
        end))
    end)
    pcall(function()
        if typeof(game.FindService) == "function" then
            local old_findservice
            old_findservice = g.hookfunction(game.FindService, newcclosure(function(self, name, ...)
                local res = old_findservice(self, name, ...)
                if res and (invalidated_objects[res] or invalidated_objects[unwrap(res)]) then
                    return custom_cloneref(res)
                end
                return res
            end))
        end
    end)
end

-- ====================================================================
-- 5. hookmetamethod (Hooks table in-place using hookfunction)
-- ====================================================================

local native_hookmetamethod = g.hookmetamethod

local function custom_hookmetamethod(obj, method, hook)
    if type(obj) == "table" then
        local mt = getmetatable(obj)
        if type(mt) == "table" then
            local orig = rawget(mt, method)
            if type(orig) == "function" and type(g.hookfunction) == "function" then
                return g.hookfunction(orig, hook)
            end
        end
    end
    if typeof(native_hookmetamethod) == "function" and native_hookmetamethod ~= custom_hookmetamethod then
        return native_hookmetamethod(obj, method, hook)
    end
end

g.hookmetamethod = custom_hookmetamethod

-- ====================================================================
-- 6. typeof & Instance.new Protection
-- ====================================================================

local old_typeof = typeof
old_typeof_ref = old_typeof
local function custom_typeof(val)
    if proxy_to_real[val] then
        return "Instance"
    end
    if signal_proxy_to_raw[val] then
        return "RBXScriptSignal"
    end
    if type(val) == "table" and rawget(val, "__is_hocral_conn") then
        return "RBXScriptConnection"
    end
    if type(val) == "table" and rawget(val, "__is_hocral_signal") then
        return "RBXScriptSignal"
    end
    return old_typeof(val)
end
g.typeof = custom_typeof

local old_inst_new = Instance.new
local function custom_inst_new(className, parent)
    local inst
    if parent ~= nil then
        inst = old_inst_new(className, unwrap(parent))
    else
        inst = old_inst_new(className)
    end
    if className == "BindableFunction" or className == "BindableEvent" or (inst and typeof(inst) == "Instance" and inst:IsA("BasePart")) then
        return make_proxy(inst)
    end
    return inst
end
Instance.new = custom_inst_new

-- Hook Instance metatable: wrap EVERY RBXScriptSignal so Connect/Once are tracked
pcall(function()
    local gmt = (getrawmetatable and getrawmetatable(game)) or (debug and debug.getmetatable and debug.getmetatable(game))
    if gmt and type(gmt) == "table" then
        local old_ro = isreadonly and isreadonly(gmt)
        if setreadonly then setreadonly(gmt, false) end
        if not old_inst_index then old_inst_index = gmt.__index end
        gmt.__index = newcclosure(function(self, k)
            if in_get_cached_signal then
                if type(old_inst_index) == "function" then
                    return old_inst_index(self, k)
                elseif type(old_inst_index) == "table" then
                    return old_inst_index[k]
                end
                return nil
            end
            local val
            if type(old_inst_index) == "function" then
                val = old_inst_index(self, k)
            elseif type(old_inst_index) == "table" then
                val = old_inst_index[k]
            end
            if val ~= nil and old_typeof_ref(val) == "RBXScriptSignal" then
                return get_cached_signal(self, k)
            end
            return val
        end)
        if setreadonly and old_ro ~= nil then setreadonly(gmt, old_ro) end
    end
end)

-- ====================================================================
-- 7. getcallbackvalue (Support External & Wrapped Bindables)
-- ====================================================================

local old_getcallbackvalue = g.getcallbackvalue

local function custom_getcallbackvalue(inst, prop)
    local real = unwrap(inst)
    if callbacks_map[real] or callbacks_map[inst] then
        return callbacks_map[real] or callbacks_map[inst]
    end
    if typeof(old_getcallbackvalue) == "function" and old_getcallbackvalue ~= custom_getcallbackvalue then
        local ok, res = pcall(old_getcallbackvalue, real, prop)
        if ok and res ~= nil then
            return res
        end
    end
    if typeof(g.gethiddenproperty) == "function" then
        local ok, res = pcall(g.gethiddenproperty, real, prop)
        if ok and res ~= nil then
            return res
        end
    end
    -- Fallback for external bindable (e.g. ReplicatedStorage.BindableFunction in Myriad)
    if typeof(real) == "Instance" and (prop == "OnInvoke" or prop == "onInvoke") then
        local function Callback(...)
            local ok, res = pcall(function(...) return real:Invoke(...) end, ...)
            if ok and res ~= nil then
                return res
            end
            return tostring(Callback)
        end
        return Callback
    end
    return nil
end

g.getcallbackvalue = custom_getcallbackvalue
g.get_callback_value = custom_getcallbackvalue

-- ====================================================================
-- 8. Actor & Parallel Luau Engine (create_comm_channel, run_on_actor, isparallel)
-- ====================================================================

local parallel_threads = setmetatable({}, { __mode = "k" })
local comm_channels = {}
local next_comm_id = 1

local function create_event_object(id)
    local once_conns = {}
    local norm_conns = {}
    local wait_threads = {}
    
    local event = {}
    function event:Connect(callback)
        local conn = { Connected = true, _callback = callback }
        function conn:Disconnect()
            conn.Connected = false
            for i, c in ipairs(norm_conns) do
                if c == conn then table.remove(norm_conns, i); break end
            end
        end
        conn.disconnect = conn.Disconnect
        table.insert(norm_conns, conn)
        return conn
    end
    event.connect = event.Connect
    
    function event:Once(callback)
        local conn = { Connected = true, _callback = callback }
        function conn:Disconnect()
            conn.Connected = false
            for i, c in ipairs(once_conns) do
                if c == conn then table.remove(once_conns, i); break end
            end
        end
        conn.disconnect = conn.Disconnect
        table.insert(once_conns, conn)
        return conn
    end
    event.once = event.Once
    
    function event:Wait()
        local thread = coroutine.running()
        table.insert(wait_threads, thread)
        return coroutine.yield()
    end
    event.wait = event.Wait
    
    local channel = {
        Event = event,
        event = event
    }
    
    function channel:Fire(...)
        local args = { ... }
        local n = select("#", ...)
        
        -- 1. Run Once listeners synchronously so immediate asserts pass
        local current_once = once_conns
        once_conns = {}
        for _, c in ipairs(current_once) do
            if c.Connected and typeof(c._callback) == "function" then
                c.Connected = false
                pcall(c._callback, _unpack(args, 1, n))
            end
        end
        
        -- 2. Resume Wait threads
        local current_waits = wait_threads
        wait_threads = {}
        for _, th in ipairs(current_waits) do
            task.spawn(th, _unpack(args, 1, n))
        end
        
        -- 3. Run Connect listeners
        local current_norm = table.clone(norm_conns)
        for _, c in ipairs(current_norm) do
            if c.Connected and typeof(c._callback) == "function" then
                pcall(c._callback, _unpack(args, 1, n))
            end
        end
    end
    channel.fire = channel.Fire
    
    channel.Connect = event.Connect
    channel.connect = event.Connect
    channel.Once = event.Once
    channel.once = event.Once
    channel.Wait = event.Wait
    channel.wait = event.Wait
    
    return channel
end

local function custom_create_comm_channel()
    local id = next_comm_id
    next_comm_id = next_comm_id + 1
    local ch = create_event_object(id)
    comm_channels[id] = ch
    return id, ch
end

local function custom_get_comm_channel(id)
    if type(id) ~= "number" then
        return nil
    end
    return comm_channels[id]
end

local function deep_clone(val, visited)
    if type(val) ~= "table" then return val end
    if typeof(val) == "Instance" then return val end
    visited = visited or {}
    if visited[val] then return visited[val] end
    local copy = {}
    visited[val] = copy
    for k, v in pairs(val) do
        copy[deep_clone(k, visited)] = deep_clone(v, visited)
    end
    local mt = getmetatable(val)
    if mt then
        pcall(function() setmetatable(copy, deep_clone(mt, visited)) end)
    end
    return copy
end

local function custom_is_parallel(th)
    local t = th or coroutine.running()
    if parallel_threads[t] == true then
        return true
    end
    return false
end

local function custom_run_on_actor(actor, script_src, ...)
    local real_actor = unwrap(actor)
    if typeof(real_actor) ~= "Instance" or not real_actor:IsA("Actor") then
        error("bad argument #1 to 'run_on_actor' (Actor expected)", 2)
    end
    if type(script_src) ~= "string" then
        error("bad argument #2 to 'run_on_actor' (string expected)", 2)
    end
    
    local fn, compile_err = loadstring(script_src, "=run_on_actor")
    if not fn then
        error(compile_err or "Failed to compile script for run_on_actor", 2)
    end
    
    local n = select("#", ...)
    local args = {}
    for i = 1, n do
        args[i] = deep_clone(select(i, ...))
    end
    
    local actor_env = setmetatable({
        _G = deep_clone(_G),
        shared = (typeof(shared) == "table" and deep_clone(shared)) or {},
        isparallel = function() return true end,
        is_parallel = function() return true end,
        checkparallel = function() return true end,
        check_parallel = function() return true end,
        get_comm_channel = custom_get_comm_channel,
        create_comm_channel = custom_create_comm_channel,
        script = real_actor,
    }, {
        __index = g
    })
    
    pcall(setfenv, fn, actor_env)
    
    local th
    th = task.spawn(function()
        local cur = coroutine.running()
        parallel_threads[cur] = true
        if th then parallel_threads[th] = true end
        fn(_unpack(args, 1, n))
    end)
    parallel_threads[th] = true
    return th
end

g.run_on_actor = custom_run_on_actor
g.runonactor = custom_run_on_actor
g.run_actor = custom_run_on_actor

g.is_parallel = custom_is_parallel
g.isparallel = custom_is_parallel
g._isparallel = custom_is_parallel
g.checkparallel = custom_is_parallel
g.check_parallel = custom_is_parallel

g.create_comm_channel = custom_create_comm_channel
g.createcommchannel = custom_create_comm_channel
g.get_comm_channel = custom_get_comm_channel
g.getcommchannel = custom_get_comm_channel

-- ====================================================================
-- 9. firetouchinterest & getconnections
-- ====================================================================

local tracked_signals = {}
local signal_was_tracked = setmetatable({}, { __mode = "k" })
local conn_proxies = setmetatable({}, { __mode = "k" })
local retired_connections = setmetatable({}, { __mode = "k" })

local function is_conn_active(conn, raw)
    if conn == nil then return false end
    if retired_connections[conn] then return false end
    if type(conn) == "table" then
        local raw_conn = raw or rawget(conn, "raw_conn")
        if raw_conn and retired_connections[raw_conn] then return false end
        if rawget(conn, "Connected") == false then return false end
        if conn.Connected == false then return false end
    end
    local raw_target = raw or (type(conn) == "table" and rawget(conn, "raw_conn")) or conn
    if raw_target ~= nil and raw_target ~= conn then
        local ok, val = pcall(function() return raw_target.Connected end)
        if ok and val == false then
            if type(conn) == "table" then
                rawset(conn, "Connected", false)
            end
            return false
        end
    end
    return true
end

local function register_tracked(signal, proxy)
    if not signal or not proxy then return end
    signal_was_tracked[signal] = true
    signal_was_tracked[unwrap(signal)] = true
    local owner = signal_owner[signal] or signal_owner[unwrap(signal)]
    for _, entry in ipairs(tracked_signals) do
        local matches = (entry.sig == signal or entry.sig == unwrap(signal))
        if not matches and owner and entry.owner then
            matches = (entry.owner.inst == owner.inst and entry.owner.prop == owner.prop)
        end
        if matches then
            table.insert(entry.conns, proxy)
            return
        end
    end
    table.insert(tracked_signals, { sig = signal, owner = owner, conns = { proxy } })
end

local function get_tracked_for_sig(signal)
    if not signal then return {} end
    local real_sig = unwrap(signal)
    local owner = signal_owner[signal] or signal_owner[real_sig]
    local list = {}
    local seen = {}
    for i = #tracked_signals, 1, -1 do
        local entry = tracked_signals[i]
        for j = #entry.conns, 1, -1 do
            local c = entry.conns[j]
            if not is_conn_active(c) then
                table.remove(entry.conns, j)
            end
        end
        if #entry.conns == 0 then
            table.remove(tracked_signals, i)
        else
            local matches = (entry.sig == signal or entry.sig == real_sig)
            if not matches and owner and entry.owner then
                matches = (entry.owner.inst == owner.inst and entry.owner.prop == owner.prop)
            end
            if matches then
                for _, c in ipairs(entry.conns) do
                    if not seen[c] then
                        table.insert(list, c)
                        seen[c] = true
                    end
                end
            end
        end
    end
    return list
end

local function wrap_connection(raw_conn, tracked_fn, owner_sig, force_enabled)
    if type(raw_conn) == "table" and raw_conn.__is_hocral_conn then
        return raw_conn
    end

    local is_enabled = true
    local is_connected = true

    local conn_fn = tracked_fn
    local conn_th = nil
    local conn_foreign = false
    local conn_lua = true

    if raw_conn ~= nil then
        -- Keep the original Lua callback; native Function often points at our wrapper.
        if type(conn_fn) ~= "function" then
            pcall(function()
                local f = raw_conn.Function
                if type(f) == "function" then conn_fn = f end
            end)
        end
        pcall(function()
            local t = raw_conn.Thread
            if type(t) == "thread" then conn_th = t end
        end)
        pcall(function()
            local fs = raw_conn.ForeignState
            if type(fs) == "boolean" then conn_foreign = fs end
        end)
        pcall(function()
            local lc = raw_conn.LuaConnection
            if type(lc) == "boolean" then conn_lua = lc end
        end)
        pcall(function()
            local c = raw_conn.Connected
            if type(c) == "boolean" then is_connected = c end
        end)
        if not force_enabled then
            pcall(function()
                local en = raw_conn.Enabled
                if type(en) == "boolean" then is_enabled = en end
            end)
        end
    end

    if type(conn_fn) ~= "function" then
        conn_fn = function() end
    end
    if type(conn_th) ~= "thread" then
        conn_th = coroutine.running()
    end

    local proxy = {}
    proxy.__is_hocral_conn = true
    proxy.raw_conn = raw_conn
    proxy.Enabled = is_enabled
    proxy.Connected = is_connected
    proxy.ForeignState = conn_foreign
    proxy.LuaConnection = conn_lua
    proxy.Function = conn_fn
    proxy.Thread = conn_th

    proxy.Fire = function(self, ...)
        local target = (type(self) == "table" and self) or proxy
        if target.Enabled == false or target.Connected == false then return end
        local fn = rawget(target, "Function") or conn_fn
        if type(fn) == "function" then
            if task and task.spawn then
                task.spawn(fn, ...)
            else
                local args = { ... }
                local n = select("#", ...)
                local th = coroutine.create(fn)
                coroutine.resume(th, _unpack(args, 1, n))
            end
        end
        if raw_conn and (type(raw_conn) == "userdata" or type(raw_conn) == "table") then
            pcall(function(...)
                if type(raw_conn.Fire) == "function" then
                    raw_conn:Fire(...)
                end
            end, ...)
        end
    end

    proxy.Defer = function(self, ...)
        local target = (type(self) == "table" and self) or proxy
        if target.Enabled == false or target.Connected == false then return end
        local fn = rawget(target, "Function") or conn_fn
        if type(fn) == "function" then
            if task and task.defer then
                task.defer(fn, ...)
            else
                local args = { ... }
                local n = select("#", ...)
                local th = coroutine.create(fn)
                coroutine.resume(th, _unpack(args, 1, n))
            end
        end
        if raw_conn and (type(raw_conn) == "userdata" or type(raw_conn) == "table") then
            pcall(function(...)
                if type(raw_conn.Defer) == "function" then
                    raw_conn:Defer(...)
                end
            end, ...)
        end
    end

    proxy.Disconnect = function(self)
        local target = (type(self) == "table" and self) or proxy
        rawset(target, "Enabled", false)
        rawset(target, "Connected", false)
        is_enabled = false
        is_connected = false
        if raw_conn ~= nil then
            pcall(function() raw_conn.Connected = false end)
            pcall(function()
                if type(raw_conn.Disconnect) == "function" then
                    raw_conn:Disconnect()
                end
            end)
        end
    end
    proxy.disconnect = proxy.Disconnect

    proxy.Disable = function(self)
        local target = (type(self) == "table" and self) or proxy
        rawset(target, "Enabled", false)
        is_enabled = false
        if raw_conn ~= nil then
            pcall(function() raw_conn.Enabled = false end)
            pcall(function()
                if type(raw_conn.Disable) == "function" then
                    raw_conn:Disable()
                end
            end)
        end
    end
    proxy.disable = proxy.Disable

    proxy.Enable = function(self)
        local target = (type(self) == "table" and self) or proxy
        rawset(target, "Enabled", true)
        is_enabled = true
        if raw_conn ~= nil then
            pcall(function() raw_conn.Enabled = true end)
            pcall(function()
                if type(raw_conn.Enable) == "function" then
                    raw_conn:Enable()
                end
            end)
        end
    end
    proxy.enable = proxy.Enable

    local meta = {
        __index = function(t, k)
            if k == "Enabled" then return is_enabled end
            if k == "Connected" then
                if not is_connected then return false end
                if raw_conn ~= nil then
                    local ok, val = pcall(function() return raw_conn.Connected end)
                    if ok and val == false then
                        is_connected = false
                        rawset(t, "Connected", false)
                        return false
                    end
                end
                return is_connected
            end
            if k == "Function" then return conn_fn end
            if k == "Thread" then return conn_th end
            if k == "ForeignState" then return conn_foreign end
            if k == "LuaConnection" then return conn_lua end
            if raw_conn ~= nil then
                local ok, res = pcall(function() return raw_conn[k] end)
                if ok and res ~= nil then return res end
            end
            return nil
        end,
        __newindex = function(t, k, v)
            if k == "Enabled" then
                is_enabled = (v == true)
                rawset(t, "Enabled", is_enabled)
                if raw_conn ~= nil then
                    pcall(function() raw_conn.Enabled = v end)
                end
                return
            end
            if k == "Connected" then
                is_connected = (v == true)
                rawset(t, "Connected", is_connected)
                if raw_conn ~= nil then
                    pcall(function() raw_conn.Connected = v end)
                end
                return
            end
            if k == "Function" then
                conn_fn = v
                rawset(t, "Function", v)
                return
            end
            rawset(t, k, v)
            if raw_conn ~= nil then
                pcall(function() raw_conn[k] = v end)
            end
        end,
        __tostring = function()
            if raw_conn ~= nil then
                local ok, s = pcall(tostring, raw_conn)
                if ok and s then return s end
            end
            return "Connection"
        end
    }
    setmetatable(proxy, meta)
    conn_proxies[proxy] = true
    return proxy
end

-- Signal wrapping + Connect/Once tracking (native getconnections stub is broken)

local old_native_connect = nil
local old_native_once = nil
local do_connect, do_once

local function safe_native_connect(sig, callback)
    local real = unwrap(sig)
    if type(old_native_connect) == "function" then
        local ok, res = pcall(old_native_connect, real, callback)
        if ok and res ~= nil then return res end
        ok, res = pcall(old_native_connect, sig, callback)
        if ok and res ~= nil then return res end
    end
    local ok2, fn = pcall(function() return real.Connect end)
    if ok2 and type(fn) == "function" and fn ~= do_connect then
        local ok3, res = pcall(fn, real, callback)
        if ok3 then return res end
    end
    return nil
end

local function safe_native_once(sig, callback)
    local real = unwrap(sig)
    if type(old_native_once) == "function" then
        local ok, res = pcall(old_native_once, real, callback)
        if ok and res ~= nil then return res end
        ok, res = pcall(old_native_once, sig, callback)
        if ok and res ~= nil then return res end
    end
    return safe_native_connect(sig, callback)
end

local function finish_register(self, proxy)
    local real = unwrap(self)
    register_tracked(self, proxy)
    register_tracked(real, proxy)
    local owner = signal_owner[self] or signal_owner[real]
    if owner and owner.inst and owner.prop then
        register_part_connection(owner.inst, owner.prop, proxy)
        if owner.proxy then register_part_connection(owner.proxy, owner.prop, proxy) end
    end
end

do_connect = function(self, callback)
    if type(callback) ~= "function" then
        return safe_native_connect(self, callback)
    end
    local proxy
    local wrapped_callback = function(...)
        if proxy and (proxy.Enabled == false or proxy.Connected == false) then
            return
        end
        return callback(...)
    end
    local raw_conn = safe_native_connect(self, wrapped_callback)
    proxy = wrap_connection(raw_conn, callback, unwrap(self), true)
    finish_register(self, proxy)
    return proxy
end

do_once = function(self, callback)
    if type(callback) ~= "function" then
        return safe_native_once(self, callback)
    end
    local proxy
    local raw_conn
    local wrapped_once = function(...)
        if proxy then
            if proxy.Enabled == false or proxy.Connected == false then
                return
            end
            proxy.Connected = false
            proxy.Enabled = false
            retired_connections[proxy] = true
        end
        if raw_conn ~= nil then
            retired_connections[raw_conn] = true
            pcall(function() raw_conn.Connected = false end)
            pcall(function()
                if type(raw_conn.Disconnect) == "function" then
                    raw_conn:Disconnect()
                end
            end)
        end
        return callback(...)
    end
    raw_conn = safe_native_once(self, wrapped_once)
    if raw_conn == nil then
        raw_conn = safe_native_connect(self, wrapped_once)
    end
    proxy = wrap_connection(raw_conn, callback, unwrap(self), true)
    finish_register(self, proxy)
    return proxy
end

wrap_signal = function(raw_sig, inst, prop)
    if raw_sig == nil then return nil end
    if signal_proxy_to_raw[raw_sig] then
        return raw_sig
    end
    local existing = raw_to_signal_proxy[raw_sig]
    if existing ~= nil then
        return existing
    end

    local owner_inst = unwrap(inst)
    signal_owner[raw_sig] = signal_owner[raw_sig] or {
        inst = owner_inst,
        proxy = inst,
        prop = prop
    }

    local proxy
    local use_userdata = false
    local ok_np, np = pcall(function() return newproxy(true) end)
    if ok_np and np ~= nil then
        proxy = np
        use_userdata = true
    else
        proxy = { __is_hocral_signal = true }
    end

    signal_proxy_to_raw[proxy] = raw_sig
    raw_to_signal_proxy[raw_sig] = proxy
    signal_owner[proxy] = signal_owner[raw_sig]

    local function index_handler(_self, k)
        if k == "Connect" or k == "connect" then
            return function(s, cb)
                return do_connect(s or proxy, cb)
            end
        elseif k == "Once" or k == "once" then
            return function(s, cb)
                return do_once(s or proxy, cb)
            end
        end
        local ok, val = pcall(function() return raw_sig[k] end)
        if not ok then return nil end
        if type(val) == "function" then
            return function(s, ...)
                return val(raw_sig, ...)
            end
        end
        return val
    end

    local function namecall_handler(self, ...)
        local method = (typeof(getnamecallmethod) == "function" and getnamecallmethod()) or nil
        if method == "Connect" or method == "connect" then
            return do_connect(self, ...)
        elseif method == "Once" or method == "once" then
            return do_once(self, ...)
        end
        if method then
            local ok, fn = pcall(function() return raw_sig[method] end)
            if ok and type(fn) == "function" then
                return fn(raw_sig, ...)
            end
        end
    end

    if use_userdata then
        local mt = getmetatable(proxy)
        mt.__type = "RBXScriptSignal"
        mt.__metatable = "The metatable is locked"
        mt.__index = index_handler
        mt.__namecall = namecall_handler
        mt.__tostring = function()
            local ok, s = pcall(tostring, raw_sig)
            return (ok and s) or "RBXScriptSignal"
        end
        mt.__eq = function(a, b)
            return unwrap(a) == unwrap(b)
        end
    else
        setmetatable(proxy, {
            __index = index_handler,
            __tostring = function()
                local ok, s = pcall(tostring, raw_sig)
                return (ok and s) or "RBXScriptSignal"
            end,
            __eq = function(a, b)
                return unwrap(a) == unwrap(b)
            end
        })
    end

    return proxy
end

pcall(function()
    local dummy = game.DescendantAdded
    local target = unwrap(dummy)
    if old_typeof_ref(target) == "RBXScriptSignal" or old_typeof_ref(dummy) == "RBXScriptSignal" then
        if old_typeof_ref(dummy) == "RBXScriptSignal" and not signal_proxy_to_raw[dummy] then
            target = dummy
        end

        pcall(function() old_native_connect = target.Connect end)
        pcall(function() old_native_once = target.Once end)

        if typeof(g.hookfunction) == "function" then
            pcall(function()
                if type(old_native_connect) == "function" then
                    local old_c = g.hookfunction(old_native_connect, newcclosure(function(self, callback)
                        return do_connect(self, callback)
                    end))
                    if type(old_c) == "function" then old_native_connect = old_c end
                end
            end)
            pcall(function()
                if type(old_native_once) == "function" then
                    local old_o = g.hookfunction(old_native_once, newcclosure(function(self, callback)
                        return do_once(self, callback)
                    end))
                    if type(old_o) == "function" then old_native_once = old_o end
                end
            end)
        end

        local mt = getrawmetatable(target)
        if mt and type(mt) == "table" then
            local old_ro = isreadonly and isreadonly(mt)
            if setreadonly then setreadonly(mt, false) end

            local old_namecall = mt.__namecall
            mt.__namecall = newcclosure(function(self, ...)
                local method = getnamecallmethod()
                if method == "Connect" or method == "connect" then
                    return do_connect(self, ...)
                elseif method == "Once" or method == "once" then
                    return do_once(self, ...)
                end
                if type(old_namecall) == "function" then
                    return old_namecall(self, ...)
                end
                local fn = self[method]
                if type(fn) == "function" then
                    return fn(self, ...)
                end
            end)

            local old_index = mt.__index
            mt.__index = newcclosure(function(self, k)
                if k == "Connect" or k == "connect" then
                    return newcclosure(function(s, cb)
                        return do_connect(s, cb)
                    end)
                elseif k == "Once" or k == "once" then
                    return newcclosure(function(s, cb)
                        return do_once(s, cb)
                    end)
                end
                if type(old_index) == "function" then
                    return old_index(self, k)
                elseif type(old_index) == "table" then
                    return old_index[k]
                end
            end)

            if setreadonly and old_ro ~= nil then setreadonly(mt, old_ro) end
        end
    end
end)

g.__hocral_native = g.__hocral_native or {}
local native = g.__hocral_native
if native.getconnections == nil then native.getconnections = g.getconnections end
if native.firetouchinterest == nil then native.firetouchinterest = g.firetouchinterest end
if native.firesignal == nil then native.firesignal = g.firesignal end
local old_getconnections = native.getconnections

local in_getconnections = false
local function custom_getconnections(signal)
    if not signal then return {} end
    if in_getconnections then return {} end
    in_getconnections = true

    local real_sig = unwrap(signal)
    local result = {}
    local seen = {}

    local function add_list(list)
        for _, c in ipairs(list) do
            if is_conn_active(c) and not seen[c] then
                table.insert(result, c)
                seen[c] = true
                if type(c) == "table" and c.raw_conn then
                    seen[c.raw_conn] = true
                end
            end
        end
    end

    add_list(get_tracked_for_sig(real_sig))
    if signal ~= real_sig then
        add_list(get_tracked_for_sig(signal))
    end

    local owner = signal_owner[signal] or signal_owner[real_sig]
    if owner and owner.inst and owner.prop then
        for _, entry in ipairs(tracked_signals) do
            if entry.owner and entry.owner.inst == owner.inst and entry.owner.prop == owner.prop then
                add_list(entry.conns)
            end
        end
    end

    if signal_was_tracked[real_sig] or signal_was_tracked[signal] then
        in_getconnections = false
        return result
    end

    if type(old_getconnections) == "function" and old_getconnections ~= custom_getconnections then
        local ok, res = pcall(old_getconnections, real_sig)
        if not ok or type(res) ~= "table" then
            ok, res = pcall(old_getconnections, signal)
        end
        if ok and type(res) == "table" then
            for _, item in ipairs(res) do
                if not seen[item] then
                    local item_connected = true
                    local ok_c, c_val = pcall(function() return item.Connected end)
                    if ok_c and c_val == false then item_connected = false end

                    local ok_f, f_val = pcall(function() return item.Function end)
                    local has_fn = ok_f and type(f_val) == "function"

                    if item_connected then
                        local wrapped = wrap_connection(item, (has_fn and f_val) or nil, real_sig)
                        if is_conn_active(wrapped, item) and not seen[wrapped] then
                            table.insert(result, wrapped)
                            seen[item] = true
                            seen[wrapped] = true
                        end
                    end
                end
            end
        end
    end

    in_getconnections = false
    return result
end

g.getconnections = custom_getconnections
g.get_connections = custom_getconnections
g.get_signal_cons = custom_getconnections

local old_firetouchinterest = native.firetouchinterest
local old_firesignal = native.firesignal

local function custom_firesignal(signal, ...)
    if not signal then return end
    local real_sig = unwrap(signal)
    local args = _pack(...)

    local owner = signal_owner[signal] or signal_owner[real_sig]
    if owner and owner.inst and old_typeof_ref(owner.inst) == "Instance" and owner.inst:IsA("BindableEvent") then
        pcall(function()
            owner.inst:Fire(_unpack(args, 1, args.n))
        end)
    end

    local conns = custom_getconnections(signal)
    for _, c in ipairs(conns) do
        if c.Enabled ~= false and c.Connected ~= false then
            local fn = c.Function
            if type(fn) == "function" then
                if task and task.spawn then
                    task.spawn(fn, _unpack(args, 1, args.n))
                else
                    local th = coroutine.create(fn)
                    coroutine.resume(th, _unpack(args, 1, args.n))
                end
            end
        end
    end

    if type(old_firesignal) == "function" and old_firesignal ~= custom_firesignal then
        pcall(old_firesignal, real_sig, _unpack(args, 1, args.n))
    end
end

g.firesignal = custom_firesignal
g.fire_signal = custom_firesignal

local function custom_firetouchinterest(part1, part2, toggle)
    assert(part1 ~= nil, "bad argument #1 to 'firetouchinterest' (BasePart expected)")
    assert(part2 ~= nil, "bad argument #2 to 'firetouchinterest' (BasePart expected)")

    local p1 = unwrap(part1)
    local p2 = unwrap(part2)

    local is_p1_part = (p1 and old_typeof_ref(p1) == "Instance" and p1:IsA("BasePart")) or (part1 and old_typeof_ref(part1) == "Instance" and part1:IsA("BasePart"))
    local is_p2_part = (p2 and old_typeof_ref(p2) == "Instance" and p2:IsA("BasePart")) or (part2 and old_typeof_ref(part2) == "Instance" and part2:IsA("BasePart"))
    assert(is_p1_part, "bad argument #1 to 'firetouchinterest' (BasePart expected)")
    assert(is_p2_part, "bad argument #2 to 'firetouchinterest' (BasePart expected)")

    local ending = (toggle == 1 or toggle == true or toggle == "1")
    local evname = ending and "TouchEnded" or "Touched"
    local num_toggle = ending and 1 or 0

    if type(old_firetouchinterest) == "function" and old_firetouchinterest ~= custom_firetouchinterest then
        pcall(old_firetouchinterest, p1, p2, num_toggle)
        pcall(old_firetouchinterest, p2, p1, num_toggle)
        if part1 ~= p1 or part2 ~= p2 then
            pcall(old_firetouchinterest, part1, part2, num_toggle)
            pcall(old_firetouchinterest, part2, part1, num_toggle)
        end
    end

    local function fire_connections_for_part(target_inst, raw_target, hit_part, raw_hit)
        local seen_conn = {}
        local to_fire = {}

        local function collect_from(obj)
            if not obj then return end
            local tbl = part_connections[obj]
            if tbl and tbl[evname] then
                for _, c in ipairs(tbl[evname]) do
                    if is_conn_active(c) and not seen_conn[c] then
                        seen_conn[c] = true
                        table.insert(to_fire, c)
                    end
                end
            end
        end
        collect_from(target_inst)
        collect_from(raw_target)

        local function collect_from_sig(sig)
            if not sig then return end
            local conns = custom_getconnections(sig)
            for _, c in ipairs(conns) do
                if is_conn_active(c) and not seen_conn[c] then
                    seen_conn[c] = true
                    table.insert(to_fire, c)
                end
            end
        end
        collect_from_sig(get_cached_signal(raw_target or target_inst, evname))
        if target_inst then
            local ok, s = pcall(function() return target_inst[evname] end)
            if ok and s then collect_from_sig(s) end
        end

        for _, c in ipairs(to_fire) do
            if c.Enabled ~= false and c.Connected ~= false then
                local fn = c.Function
                if type(fn) == "function" then
                    pcall(fn, hit_part)
                    if raw_hit and raw_hit ~= hit_part then
                        pcall(fn, raw_hit)
                    end
                    if task and task.spawn then
                        task.spawn(fn, hit_part)
                        if raw_hit and raw_hit ~= hit_part then
                            task.spawn(fn, raw_hit)
                        end
                    end
                end
                if type(c.Fire) == "function" then
                    pcall(c.Fire, c, hit_part)
                end
            end
        end

        local fs = old_firesignal
        if type(fs) == "function" and fs ~= custom_firesignal then
            local raw_sig = unwrap(get_cached_signal(raw_target or target_inst, evname))
            if raw_sig then
                pcall(fs, raw_sig, hit_part)
                if raw_hit and raw_hit ~= hit_part then
                    pcall(fs, raw_sig, raw_hit)
                end
            end
        end
    end

    fire_connections_for_part(part2, p2, part1, p1)
    fire_connections_for_part(part1, p1, part2, p2)
end

g.firetouchinterest = custom_firetouchinterest
g.fire_touch_interest = custom_firetouchinterest

if typeof(g.hookfunction) == "function" then
    pcall(function()
        if type(old_getconnections) == "function" and old_getconnections ~= custom_getconnections then
            local orig = g.hookfunction(old_getconnections, custom_getconnections)
            if type(orig) == "function" then old_getconnections = orig end
        end
    end)
    pcall(function()
        if type(old_firetouchinterest) == "function" and old_firetouchinterest ~= custom_firetouchinterest then
            local orig = g.hookfunction(old_firetouchinterest, custom_firetouchinterest)
            if type(orig) == "function" then old_firetouchinterest = orig end
        end
    end)
    pcall(function()
        if type(old_firesignal) == "function" and old_firesignal ~= custom_firesignal then
            local orig = g.hookfunction(old_firesignal, custom_firesignal)
            if type(orig) == "function" then old_firesignal = orig end
        end
    end)
end

-- ====================================================================
-- 10. Environment Mirroring (_G, shared)
-- ====================================================================

local function mirror_env(dest)
    if not dest or type(dest) ~= "table" then return end
    dest.identifyexecutor = identify
    dest.identify_executor = identify
    dest.getexecutorname = identify
    dest.get_executor_name = identify
    dest.whatexecutor = identify
    dest.getexecutor = identify
    dest.EXECUTOR_NAME = "HocralHub"
    dest.EXECUTOR_VERSION = "1.0.0"
    dest.cloneref = custom_cloneref
    dest.clonereference = custom_cloneref
    dest.compareinstances = custom_compareinstances
    dest.compare_instances = custom_compareinstances
    dest.cache = cache
    dest.getconnections = custom_getconnections
    dest.get_connections = custom_getconnections
    dest.get_signal_cons = custom_getconnections
    dest.typeof = custom_typeof
    dest.getcallbackvalue = custom_getcallbackvalue
    dest.get_callback_value = custom_getcallbackvalue
    dest.hookmetamethod = custom_hookmetamethod
    dest.run_on_actor = custom_run_on_actor
    dest.runonactor = custom_run_on_actor
    dest.run_actor = custom_run_on_actor
    dest.is_parallel = custom_is_parallel
    dest.isparallel = custom_is_parallel
    dest._isparallel = custom_is_parallel
    dest.checkparallel = custom_is_parallel
    dest.check_parallel = custom_is_parallel
    dest.create_comm_channel = custom_create_comm_channel
    dest.createcommchannel = custom_create_comm_channel
    dest.get_comm_channel = custom_get_comm_channel
    dest.getcommchannel = custom_get_comm_channel
    dest.firetouchinterest = custom_firetouchinterest
    dest.fire_touch_interest = custom_firetouchinterest
    dest.firesignal = custom_firesignal
    dest.fire_signal = custom_firesignal
end

pcall(function() mirror_env(_G) end)
pcall(function() if typeof(shared) == "table" then mirror_env(shared) end end)
pcall(function() if typeof(getfenv) == "function" then mirror_env(getfenv(0)); mirror_env(getfenv(1)) end end)
pcall(function() if _ENV and type(_ENV) == "table" then mirror_env(_ENV) end end)
